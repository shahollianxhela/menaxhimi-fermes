<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\KafsheController;
use App\Http\Controllers\PunonjesController;
use App\Http\Controllers\ProduktController;
use App\Http\Controllers\MesazhController;
use App\Http\Controllers\RaportController;

Route::get('/', function () {
    return view('welcome');
});

// Kafshe
Route::resource('kafshe', KafsheController::class);

// Punonjes
Route::resource('punonjes', PunonjesController::class);

// Produkte
Route::resource('produkte', ProduktController::class);

// Chat me veterinerin
Route::get('chat', [MesazhController::class, 'index'])->name('chat.index');
Route::post('chat', [MesazhController::class, 'store'])->name('chat.store');

// Raport PDF
Route::get('/raport', [RaportController::class, 'eksportRaport'])->name('raport.eksport');

// Auth Routes (Laravel Breeze)
require __DIR__.'/auth.php';
