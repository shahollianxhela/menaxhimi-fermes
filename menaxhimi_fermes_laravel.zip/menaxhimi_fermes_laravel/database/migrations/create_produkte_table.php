<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('produkte', function (Blueprint $table) {
            $table->id();
            $table->string('emri');
            $table->integer('sasia')->default(0);
            $table->decimal('cmimi', 8, 2);
            $table->string('lloji')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('produkte');
    }
};
