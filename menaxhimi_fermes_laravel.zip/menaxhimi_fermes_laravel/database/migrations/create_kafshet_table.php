<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('kafshet', function (Blueprint $table) {
            $table->id();
            $table->string('lloji');
            $table->string('gjinia');
            $table->date('data_lindjes');
            $table->float('pesha');
            $table->string('statusi_vaksinimit')->nullable();
            $table->string('dieta')->nullable();
            $table->string('gjendja_shendetesore')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kafshet');
    }
};
