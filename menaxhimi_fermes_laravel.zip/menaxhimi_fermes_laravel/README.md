# Menaxhimi i Fermës – Laravel App

Ky është një aplikacion Laravel për menaxhimin e një ferme që përfshin:

- Regjistrim të kafshëve
- Menaxhim të punonjësve
- Shit-blerje të produkteve
- Chat online me veterinerin
- Gjenerim raportesh PDF

---

## 1. Kërkesat

- PHP ≥ 8.1
- Composer
- Node.js & npm
- MySQL
- Laravel CLI (opsionale)

---

## 2. Hapat për Instalimin:

1. Bëje Extract projektin.
2. Hap terminalin brenda folderit të projektit.
3. Ekzekuto komandat:


```bash
composer install
npm install
npm run dev
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan db:seed
php artisan serve


http://127.0.0.1:8000


Email | admin@ferma.com 
Password | password