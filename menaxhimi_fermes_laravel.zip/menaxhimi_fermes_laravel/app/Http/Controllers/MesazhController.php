<?php

namespace App\Http\Controllers;

use App\Models\Mesazh;
use Illuminate\Http\Request;

class MesazhController extends Controller
{
    public function index()
    {
        $mesazhet = Mesazh::all();
        return view('chat.index', compact('mesazhet'));
    }

    public function store(Request $request)
    {
        Mesazh::create([
            'user_id' => auth()->id(),
            'mesazhi' => $request->mesazhi,
        ]);

        return redirect()->route('chat.index');
    }
}
