<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class RaportController extends Controller
{
    public function eksportRaport()
    {
        $data = [
            'titulli' => 'Raport i Fermës',
            'data' => now()
        ];

        $pdf = Pdf::loadView('raporte.ferma', $data);
        return $pdf->download('raport_ferme.pdf');
    }
}
