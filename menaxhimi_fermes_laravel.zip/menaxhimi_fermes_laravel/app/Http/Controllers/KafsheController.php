<?php

namespace App\Http\Controllers;

use App\Models\Kafshe;
use Illuminate\Http\Request;

class KafsheController extends Controller
{
    public function index()
    {
        $kafshet = Kafshe::all();
        return view('kafshe.index', compact('kafshet'));
    }

    public function create()
    {
        return view('kafshe.create');
    }

    public function store(Request $request)
    {
        Kafshe::create($request->all());
        return redirect()->route('kafshe.index');
    }

    public function edit(Kafshe $kafshe)
    {
        return view('kafshe.edit', compact('kafshe'));
    }

    public function update(Request $request, Kafshe $kafshe)
    {
        $kafshe->update($request->all());
        return redirect()->route('kafshe.index');
    }

    public function destroy(Kafshe $kafshe)
    {
        $kafshe->delete();
        return redirect()->route('kafshe.index');
    }
}
