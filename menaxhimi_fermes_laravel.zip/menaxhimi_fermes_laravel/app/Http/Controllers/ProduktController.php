<?php

namespace App\Http\Controllers;

use App\Models\Produkt;
use Illuminate\Http\Request;

class ProduktController extends Controller
{
    public function index()
    {
        $produktet = Produkt::all();
        return view('produkte.index', compact('produktet'));
    }

    public function create()
    {
        return view('produkte.create');
    }

    public function store(Request $request)
    {
        Produkt::create($request->all());
        return redirect()->route('produkte.index');
    }

    public function edit(Produkt $produkt)
    {
        return view('produkte.edit', compact('produkt'));
    }

    public function update(Request $request, Produkt $produkt)
    {
        $produkt->update($request->all());
        return redirect()->route('produkte.index');
    }

    public function destroy(Produkt $produkt)
    {
        $produkt->delete();
        return redirect()->route('produkte.index');
    }
}
