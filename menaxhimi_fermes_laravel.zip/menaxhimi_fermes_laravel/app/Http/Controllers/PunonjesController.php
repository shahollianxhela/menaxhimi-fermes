<?php

namespace App\Http\Controllers;

use App\Models\Punonjes;
use Illuminate\Http\Request;

class PunonjesController extends Controller
{
    public function index()
    {
        $punonjesit = Punonjes::all();
        return view('punonjes.index', compact('punonjesit'));
    }

    public function create()
    {
        return view('punonjes.create');
    }

    public function store(Request $request)
    {
        Punonjes::create($request->all());
        return redirect()->route('punonjes.index');
    }

    public function edit(Punonjes $punonjes)
    {
        return view('punonjes.edit', compact('punonjes'));
    }

    public function update(Request $request, Punonjes $punonjes)
    {
        $punonjes->update($request->all());
        return redirect()->route('punonjes.index');
    }

    public function destroy(Punonjes $punonjes)
    {
        $punonjes->delete();
        return redirect()->route('punonjes.index');
    }
}
