<?php
namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class DetyreNotifikim extends Notification implements ShouldQueue
{
    use Queueable;

    public $mesazhi;

    public function __construct($mesazhi)
    {
        $this->mesazhi = $mesazhi;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toArray($notifiable)
    {
        return ['mesazhi' => $this->mesazhi];
    }
}
