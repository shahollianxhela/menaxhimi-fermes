<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produkt extends Model
{
    protected $fillable = [
        'emri', 'sasia', 'cmimi', 'lloji'
    ];
}
