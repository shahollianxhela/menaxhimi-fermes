<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kafshe extends Model
{
    protected $fillable = [
        'lloji', 'gjinia', 'data_lindjes', 'pesha', 'statusi_vaksinimit', 'dieta', 'gjendja_shendetesore'
    ];
}
