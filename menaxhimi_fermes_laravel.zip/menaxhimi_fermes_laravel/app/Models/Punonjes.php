<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Punonjes extends Model
{
    protected $fillable = [
        'user_id', 'roli'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
