<h1>Lista e Kafshëve</h1>

<a href="{{ route('kafshe.create') }}">Shto Kafshë të Re</a>

<ul>
@foreach ($kafshet as $kafshe)
    <li>{{ $kafshe->lloji }} - {{ $kafshe->gjinia }}
        <a href="{{ route('kafshe.edit', $kafshe) }}">Ndrysho</a>
        <form action="{{ route('kafshe.destroy', $kafshe) }}" method="POST" style="display:inline">
            @csrf
            @method('DELETE')
            <button type="submit">Fshi</button>
        </form>
    </li>
@endforeach
</ul>
