<h1>Shto Kafshë</h1>

<form action="{{ route('kafshe.store') }}" method="POST">
    @csrf
    Lloji: <input type="text" name="lloji"><br>
    Gjinia: <input type="text" name="gjinia"><br>
    Data Lindjes: <input type="date" name="data_lindjes"><br>
    Pesha: <input type="number" name="pesha"><br>
    Statusi Vaksinimit: <input type="text" name="statusi_vaksinimit"><br>
    Dieta: <input type="text" name="dieta"><br>
    Gjendja Shendetesore: <input type="text" name="gjendja_shendetesore"><br>
    <button type="submit">Ruaj</button>
</form>
