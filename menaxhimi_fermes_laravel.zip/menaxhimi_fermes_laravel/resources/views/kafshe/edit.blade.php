<h1>Ndrysho Kafshë</h1>

<form action="{{ route('kafshe.update', $kafshe) }}" method="POST">
    @csrf
    @method('PUT')
    Lloji: <input type="text" name="lloji" value="{{ $kafshe->lloji }}"><br>
    Gjinia: <input type="text" name="gjinia" value="{{ $kafshe->gjinia }}"><br>
    Data Lindjes: <input type="date" name="data_lindjes" value="{{ $kafshe->data_lindjes }}"><br>
    Pesha: <input type="number" name="pesha" value="{{ $kafshe->pesha }}"><br>
    Statusi Vaksinimit: <input type="text" name="statusi_vaksinimit" value="{{ $kafshe->statusi_vaksinimit }}"><br>
    Dieta: <input type="text" name="dieta" value="{{ $kafshe->dieta }}"><br>
    Gjendja Shendetesore: <input type="text" name="gjendja_shendetesore" value="{{ $kafshe->gjendja_shendetesore }}"><br>
    <button type="submit">Përditëso</button>
</form>
