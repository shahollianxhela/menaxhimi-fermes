<h1>Lista e Punonjësve</h1>

<a href="{{ route('punonjes.create') }}">Shto Punonjës të Ri</a>

<ul>
@foreach ($punonjesit as $punonjes)
    <li>Roli: {{ $punonjes->roli }}
        <a href="{{ route('punonjes.edit', $punonjes) }}">Ndrysho</a>
        <form action="{{ route('punonjes.destroy', $punonjes) }}" method="POST" style="display:inline">
            @csrf
            @method('DELETE')
            <button type="submit">Fshi</button>
        </form>
    </li>
@endforeach
</ul>
