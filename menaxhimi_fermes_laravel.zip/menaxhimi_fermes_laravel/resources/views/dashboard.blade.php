@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Dashboard</h1>
    <div class="row mt-4">
        <div class="col-md-3"><div class="card text-white bg-success mb-3"><div class="card-body"><h5 class="card-title">Kafshë në total</h5><p class="card-text">{{ $numriKafsheve }}</p></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-primary mb-3"><div class="card-body"><h5 class="card-title">Punonjës aktivë</h5><p class="card-text">{{ $numriPunonjesve }}</p></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-warning mb-3"><div class="card-body"><h5 class="card-title">Produkte të shitura</h5><p class="card-text">{{ $shitjet }}</p></div></div></div>
        <div class="col-md-3"><div class="card text-white bg-danger mb-3"><div class="card-body"><h5 class="card-title">Produkte të blera</h5><p class="card-text">{{ $blerjet }}</p></div></div></div>
    </div>
</div>
@endsection
