<h1>Chat me Veterinerin</h1>

<ul>
@foreach ($mesazhet as $mesazh)
    <li>{{ $mesazh->user->name }}: {{ $mesazh->mesazhi }}</li>
@endforeach
</ul>

<form action="{{ route('chat.store') }}" method="POST">
    @csrf
    <input type="text" name="mesazhi" placeholder="Shkruaj mesazhin...">
    <button type="submit">Dërgo</button>
</form>
