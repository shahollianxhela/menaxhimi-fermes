<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <title>Menaxhimi i Fermës</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    @auth
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
        <a class="navbar-brand" href="/dashboard">Fermë</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item"><a class="nav-link" href="/kafshe">Kafshët</a></li>
                <li class="nav-item"><a class="nav-link" href="/punonjes">Punonjësit</a></li>
                <li class="nav-item"><a class="nav-link" href="/produkte">Shit-Blerje</a></li>
                <li class="nav-item"><a class="nav-link" href="/chat">Veterineri</a></li>
            </ul>
            <span class="navbar-text">{{ Auth::user()->name }}</span>
        </div>
    </nav>
    @endauth

    <main class="py-4">
        @yield('content')
    </main>
</body>
</html>
