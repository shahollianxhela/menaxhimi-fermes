<h1>Lista e Produkteve</h1>

<a href="{{ route('produkte.create') }}">Shto Produkt</a>

<ul>
@foreach ($produktet as $produkt)
    <li>{{ $produkt->emri }} - {{ $produkt->cmimi }} €
        <a href="{{ route('produkte.edit', $produkt) }}">Ndrysho</a>
        <form action="{{ route('produkte.destroy', $produkt) }}" method="POST" style="display:inline">
            @csrf
            @method('DELETE')
            <button type="submit">Fshi</button>
        </form>
    </li>
@endforeach
</ul>
